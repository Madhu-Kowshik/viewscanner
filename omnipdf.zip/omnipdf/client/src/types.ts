export interface FileEntry {
  id: string;
  name: string;
  size: number;
  pageCount: number;
  status: 'loading' | 'ready' | 'error';
  message?: string;
}
/** One page of the output document. The ordered array of these IS the exported PDF. */
export interface PageItem {
  id: string;
  sourceId: string;
  index: number; // 0-based page index in the source PDF
  rotation: number; // extra rotation (0/90/180/270) on top of the source page's own
}
