import { create } from 'zustand';
import { arrayMove } from '@dnd-kit/sortable';
import type { FileEntry, PageItem } from '../types';
import { errMsg, validatePdf } from '../lib/validate';
import { registerSource, releaseSource } from '../lib/sources';

const uid = () => crypto.randomUUID();

interface State {
  files: FileEntry[];
  pages: PageItem[];
  selected: Set<string>;
  addFiles: (list: File[]) => Promise<void>;
  removeFile: (id: string) => void;
  clearAll: () => void;
  toggle: (id: string) => void;
  selectAll: () => void;
  clearSelection: () => void;
  deleteSelected: () => void;
  rotateSelected: (delta: 90 | -90) => void;
  duplicateSelected: () => void;
  reorder: (activeId: string, overId: string) => void;
}

export const useWorkspace = create<State>()((set, get) => ({
  files: [],
  pages: [],
  selected: new Set(),

  async addFiles(list) {
    for (const file of list) {
      const id = uid();
      set((s) => ({
        files: [...s.files, { id, name: file.name, size: file.size, pageCount: 0, status: 'loading' }],
      }));
      try {
        const bytes = await validatePdf(file);
        const n = await registerSource(id, bytes);
        const newPages = Array.from({ length: n }, (_, i) => ({ id: uid(), sourceId: id, index: i, rotation: 0 }));
        set((s) => ({
          files: s.files.map((f) => (f.id === id ? { ...f, pageCount: n, status: 'ready' as const } : f)),
          pages: [...s.pages, ...newPages],
        }));
      } catch (e) {
        releaseSource(id);
        set((s) => ({
          files: s.files.map((f) => (f.id === id ? { ...f, status: 'error' as const, message: errMsg(e) } : f)),
        }));
      }
    }
  },

  removeFile(id) {
    releaseSource(id);
    set((s) => {
      const pages = s.pages.filter((p) => p.sourceId !== id);
      const ids = new Set(pages.map((p) => p.id));
      return {
        files: s.files.filter((f) => f.id !== id),
        pages,
        selected: new Set([...s.selected].filter((x) => ids.has(x))),
      };
    });
  },

  clearAll() {
    get().files.forEach((f) => releaseSource(f.id));
    set({ files: [], pages: [], selected: new Set() });
  },

  toggle(id) {
    set((s) => {
      const next = new Set(s.selected);
      next.has(id) ? next.delete(id) : next.add(id);
      return { selected: next };
    });
  },
  selectAll: () => set((s) => ({ selected: new Set(s.pages.map((p) => p.id)) })),
  clearSelection: () => set({ selected: new Set() }),

  deleteSelected: () =>
    set((s) => ({ pages: s.pages.filter((p) => !s.selected.has(p.id)), selected: new Set() })),

  rotateSelected: (delta) =>
    set((s) => ({
      pages: s.pages.map((p) => (s.selected.has(p.id) ? { ...p, rotation: (p.rotation + delta + 360) % 360 } : p)),
    })),

  duplicateSelected: () =>
    set((s) => ({
      pages: s.pages.flatMap((p) => (s.selected.has(p.id) ? [p, { ...p, id: uid() }] : [p])),
    })),

  reorder: (activeId, overId) =>
    set((s) => {
      const from = s.pages.findIndex((p) => p.id === activeId);
      const to = s.pages.findIndex((p) => p.id === overId);
      return from < 0 || to < 0 ? s : { pages: arrayMove(s.pages, from, to) };
    }),
}));
