import { describe, expect, it } from 'vitest';
import { PDFDocument } from 'pdf-lib';
import { buildPdf } from './pdfOps';

async function makePdf(n: number): Promise<Uint8Array> {
  const d = await PDFDocument.create();
  for (let i = 0; i < n; i++) d.addPage([100 + i * 10, 200]); // width encodes page identity
  return d.save();
}

describe('buildPdf', () => {
  it('merges, reorders, duplicates and rotates', async () => {
    const a = await makePdf(3);
    const b = await makePdf(2);
    const src: Record<string, Uint8Array> = { a, b };
    const out = await buildPdf(
      [
        { id: '1', sourceId: 'b', index: 1, rotation: 0 },
        { id: '2', sourceId: 'a', index: 2, rotation: 90 },
        { id: '3', sourceId: 'a', index: 0, rotation: 0 },
        { id: '4', sourceId: 'a', index: 0, rotation: 0 }, // duplicate
      ],
      (id) => src[id],
    );
    const doc = await PDFDocument.load(out);
    const pages = doc.getPages();
    expect(pages.length).toBe(4);
    expect(pages.map((p) => p.getWidth())).toEqual([110, 120, 100, 100]);
    expect(pages[1].getRotation().angle).toBe(90);
    expect(pages[0].getRotation().angle).toBe(0);
  });
  it('rejects an empty page list', async () => {
    await expect(buildPdf([], () => new Uint8Array())).rejects.toThrow();
  });
});
