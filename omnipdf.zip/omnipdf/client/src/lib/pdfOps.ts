import { PDFDocument, degrees, type PDFPage } from 'pdf-lib';
import type { PageItem } from '../types';

/** Builds a new PDF from an ordered list of pages (merge / extract / reorder / rotate / duplicate). */
export async function buildPdf(
  pages: PageItem[],
  getBytes: (sourceId: string) => Uint8Array,
): Promise<Uint8Array> {
  if (pages.length === 0) throw new Error('No pages to export');
  const out = await PDFDocument.create();

  // Group output positions by source so each source is parsed and copied once.
  const bySource = new Map<string, number[]>();
  pages.forEach((p, pos) => {
    const list = bySource.get(p.sourceId) ?? [];
    list.push(pos);
    bySource.set(p.sourceId, list);
  });

  const copied: PDFPage[] = new Array(pages.length);
  for (const [sourceId, positions] of bySource) {
    const src = await PDFDocument.load(getBytes(sourceId));
    const result = await out.copyPages(src, positions.map((pos) => pages[pos].index));
    positions.forEach((pos, k) => (copied[pos] = result[k]));
  }

  copied.forEach((pg, i) => {
    const extra = pages[i].rotation;
    if (extra) pg.setRotation(degrees((pg.getRotation().angle + extra) % 360));
    out.addPage(pg);
  });
  return out.save();
}

export function downloadBytes(bytes: Uint8Array, filename: string) {
  const blob = new Blob([bytes], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}
