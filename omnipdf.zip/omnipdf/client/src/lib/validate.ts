export const MAX_BYTES = 200 * 1024 * 1024;

/** Reads the file and checks the %PDF- magic bytes (does not trust MIME type or extension). */
export async function validatePdf(file: File): Promise<Uint8Array> {
  if (file.size === 0) throw new Error('File is empty');
  if (file.size > MAX_BYTES) throw new Error('File is larger than 200 MB');
  const bytes = new Uint8Array(await file.arrayBuffer());
  const head = new TextDecoder('latin1').decode(bytes.subarray(0, 1024));
  if (!head.includes('%PDF-')) throw new Error('Not a valid PDF (missing %PDF- header)');
  return bytes;
}

export const errMsg = (e: unknown): string => {
  const err = e as { name?: string; message?: string };
  if (err?.name === 'PasswordException') return 'Password-protected PDFs are not supported in Phase 1';
  return err?.message || 'Unknown error';
};
