import * as pdfjs from 'pdfjs-dist';
import type { PDFDocumentProxy } from 'pdfjs-dist';
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;

const registry = new Map<string, { bytes: Uint8Array; doc: PDFDocumentProxy }>();

export async function registerSource(id: string, bytes: Uint8Array): Promise<number> {
  // pdf.js transfers the buffer to its worker, so give it a copy and keep ours for pdf-lib.
  const doc = await pdfjs.getDocument({ data: bytes.slice() }).promise;
  registry.set(id, { bytes, doc });
  return doc.numPages;
}

export const getBytes = (id: string): Uint8Array => {
  const s = registry.get(id);
  if (!s) throw new Error('Source file is no longer loaded');
  return s.bytes;
};

export function releaseSource(id: string) {
  registry.get(id)?.doc.destroy();
  registry.delete(id);
}

// Limit concurrent renders so large documents don't flood the worker/memory.
let active = 0;
const waiting: Array<() => void> = [];
async function acquire() {
  if (active >= 3) await new Promise<void>((r) => waiting.push(r));
  active++;
}
function release() {
  active--;
  waiting.shift()?.();
}

export async function renderPage(
  sourceId: string,
  index: number,
  rotation: number,
  targetWidth: number,
  canvas: HTMLCanvasElement,
  signal: AbortSignal,
): Promise<void> {
  await acquire();
  try {
    const src = registry.get(sourceId);
    if (signal.aborted || !src) return;
    const page = await src.doc.getPage(index + 1);
    const rot = (page.rotate + rotation) % 360;
    const base = page.getViewport({ scale: 1, rotation: rot });
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const viewport = page.getViewport({ scale: (targetWidth * dpr) / base.width, rotation: rot });
    if (signal.aborted) return;
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    canvas.style.width = '100%';
    canvas.style.aspectRatio = `${base.width} / ${base.height}`;
    const task = page.render({ canvasContext: canvas.getContext('2d')!, viewport });
    signal.addEventListener('abort', () => task.cancel(), { once: true });
    await task.promise;
    page.cleanup();
  } catch (e) {
    if ((e as Error).name !== 'RenderingCancelledException') throw e;
  } finally {
    release();
  }
}
