import { useCallback, useState, type ButtonHTMLAttributes } from 'react';
import { useDropzone } from 'react-dropzone';
import {
  DndContext, closestCenter, MouseSensor, TouchSensor, useSensor, useSensors, type DragEndEvent,
} from '@dnd-kit/core';
import { SortableContext, rectSortingStrategy } from '@dnd-kit/sortable';
import { useWorkspace } from './stores/workspace';
import { buildPdf, downloadBytes } from './lib/pdfOps';
import { getBytes } from './lib/sources';
import { PageCard } from './components/PageCard';
import { Preview } from './components/Preview';
import type { PageItem } from './types';

const fmt = (n: number) => (n > 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

function Btn({ primary, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { primary?: boolean }) {
  return (
    <button
      {...p}
      className={`rounded-lg border px-3 py-2 text-sm disabled:opacity-40 ${
        primary ? 'border-indigo-400 bg-indigo-600 hover:bg-indigo-500' : 'border-white/10 bg-white/5 hover:bg-white/10'
      }`}
    />
  );
}

export default function App() {
  const s = useWorkspace();
  const [preview, setPreview] = useState<PageItem | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);

  const onDrop = useCallback((accepted: File[], rejected: { file: File }[]) => {
    if (rejected.length) setMsg({ kind: 'err', text: `Skipped non-PDF file(s): ${rejected.map((r) => r.file.name).join(', ')}` });
    void useWorkspace.getState().addFiles(accepted);
  }, []);
  const { getRootProps, getInputProps, isDragActive, open } = useDropzone({
    onDrop, noClick: true, noKeyboard: true, accept: { 'application/pdf': ['.pdf'] },
  });

  const sensors = useSensors(
    useSensor(MouseSensor, { activationConstraint: { distance: 8 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 200, tolerance: 6 } }),
  );
  const onDragEnd = (e: DragEndEvent) => {
    if (e.over && e.active.id !== e.over.id) s.reorder(String(e.active.id), String(e.over.id));
  };

  const selectedPages = s.pages.filter((p) => s.selected.has(p.id));
  const exportPages = async (list: PageItem[], name: string) => {
    setBusy(true);
    setMsg(null);
    try {
      const bytes = await buildPdf(list, getBytes);
      downloadBytes(bytes, name);
      setMsg({ kind: 'ok', text: `Exported ${list.length} page(s) as ${name} (${fmt(bytes.length)})` });
    } catch (e) {
      setMsg({ kind: 'err', text: `Export failed: ${(e as Error).message}` });
    } finally {
      setBusy(false);
    }
  };
  const none = s.selected.size === 0;

  return (
    <div {...getRootProps()} className="min-h-screen bg-gradient-to-b from-[#0b1020] to-[#141a3a]">
      <input {...getInputProps()} />
      {isDragActive && (
        <div className="pointer-events-none fixed inset-0 z-40 grid place-items-center border-4 border-dashed border-indigo-400 bg-indigo-900/60 text-xl">
          Drop PDF files here
        </div>
      )}
      <header className="px-4 pt-4">
        <h1 className="text-xl font-semibold">OmniPDF Studio</h1>
        <p className="text-sm text-slate-400">Everything you need for PDFs. · Phase 1 · UNTESTED</p>
      </header>

      <div className="sticky top-0 z-30 mt-3 flex flex-wrap gap-2 border-y border-white/10 bg-[#0b1020]/95 px-4 py-3 backdrop-blur">
        <Btn primary onClick={open}>Add PDFs</Btn>
        <Btn onClick={s.selectAll} disabled={!s.pages.length}>Select all</Btn>
        <Btn onClick={s.clearSelection} disabled={none}>Clear selection</Btn>
        <Btn onClick={() => s.rotateSelected(-90)} disabled={none}>⟲ Rotate left</Btn>
        <Btn onClick={() => s.rotateSelected(90)} disabled={none}>⟳ Rotate right</Btn>
        <Btn onClick={s.duplicateSelected} disabled={none}>Duplicate</Btn>
        <Btn onClick={s.deleteSelected} disabled={none}>Delete</Btn>
        <Btn primary disabled={none || busy} onClick={() => exportPages(selectedPages, 'omnipdf-extract.pdf')}>
          Extract selected ({s.selected.size})
        </Btn>
        <Btn primary disabled={!s.pages.length || busy} onClick={() => exportPages(s.pages, 'omnipdf-merged.pdf')}>
          Export / Merge all ({s.pages.length})
        </Btn>
        <Btn onClick={s.clearAll} disabled={!s.files.length}>Clear workspace</Btn>
      </div>

      <main className="space-y-4 p-4">
        {msg && (
          <p className={`rounded-lg p-3 text-sm ${msg.kind === 'ok' ? 'bg-emerald-500/20' : 'bg-red-500/20'}`}>{msg.text}</p>
        )}

        {s.files.length > 0 && (
          <ul className="space-y-1 text-sm">
            {s.files.map((f) => (
              <li key={f.id} className="flex items-center gap-3 rounded-lg bg-white/5 px-3 py-2">
                <span className="min-w-0 flex-1 truncate">{f.name}</span>
                <span className="text-slate-400">{fmt(f.size)}</span>
                <span className="text-slate-400">{f.status === 'ready' ? `${f.pageCount} pages` : ''}</span>
                <span className={f.status === 'error' ? 'text-red-400' : f.status === 'ready' ? 'text-emerald-400' : 'text-amber-300'}>
                  {f.status === 'error' ? f.message : f.status}
                </span>
                <button onClick={() => s.removeFile(f.id)} className="text-slate-400 hover:text-white" aria-label={`Remove ${f.name}`}>✕</button>
              </li>
            ))}
          </ul>
        )}

        {s.pages.length === 0 ? (
          <div className="grid place-items-center rounded-2xl border border-dashed border-white/20 p-16 text-center text-slate-400">
            <p>Drag and drop PDF files anywhere, or use “Add PDFs”.</p>
          </div>
        ) : (
          <>
            <p className="text-xs text-slate-400">Click a page to select it. Drag to reorder (touch: press and hold). Files are processed locally in your browser.</p>
            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
              <SortableContext items={s.pages.map((p) => p.id)} strategy={rectSortingStrategy}>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
                  {s.pages.map((p, i) => (
                    <PageCard key={p.id} page={p} number={i + 1} onPreview={() => setPreview(p)} />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
          </>
        )}
      </main>
      {preview && <Preview page={preview} onClose={() => setPreview(null)} />}
    </div>
  );
}
