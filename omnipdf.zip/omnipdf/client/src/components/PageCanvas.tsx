import { useEffect, useRef, useState } from 'react';
import { renderPage } from '../lib/sources';

interface Props {
  sourceId: string;
  index: number;
  rotation: number;
  width: number;
  lazy?: boolean;
}

export function PageCanvas({ sourceId, index, rotation, width, lazy = true }: Props) {
  const box = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const [visible, setVisible] = useState(!lazy);
  const [failed, setFailed] = useState(false);

  // Lazy: only render once the card scrolls near the viewport.
  useEffect(() => {
    if (visible || !box.current) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setVisible(true);
          io.disconnect();
        }
      },
      { rootMargin: '300px' },
    );
    io.observe(box.current);
    return () => io.disconnect();
  }, [visible]);

  useEffect(() => {
    if (!visible || !canvas.current) return;
    const ac = new AbortController();
    setFailed(false);
    renderPage(sourceId, index, rotation, width, canvas.current, ac.signal).catch(() => setFailed(true));
    return () => ac.abort();
  }, [visible, sourceId, index, rotation, width]);

  // Free canvas memory on unmount.
  useEffect(
    () => () => {
      if (canvas.current) {
        canvas.current.width = 0;
        canvas.current.height = 0;
      }
    },
    [],
  );

  return (
    <div ref={box} className="min-h-[120px] bg-white">
      {failed ? <p className="p-2 text-xs text-red-600">Render failed</p> : <canvas ref={canvas} className="block" />}
    </div>
  );
}
