import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { useWorkspace } from '../stores/workspace';
import { PageCanvas } from './PageCanvas';
import type { PageItem } from '../types';

export function PageCard({ page, number, onPreview }: { page: PageItem; number: number; onPreview: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: page.id });
  const selected = useWorkspace((s) => s.selected.has(page.id));
  const toggle = useWorkspace((s) => s.toggle);
  const fileName = useWorkspace((s) => s.files.find((f) => f.id === page.sourceId)?.name ?? '');

  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 }}
      {...attributes}
      {...listeners}
      className={`relative cursor-grab rounded-xl border p-2 ${
        selected ? 'border-indigo-400 bg-indigo-500/20' : 'border-white/10 bg-white/5'
      }`}
    >
      <div onClick={() => toggle(page.id)} className="cursor-pointer overflow-hidden rounded">
        <PageCanvas sourceId={page.sourceId} index={page.index} rotation={page.rotation} width={200} />
      </div>
      <div className="mt-2 flex items-center justify-between gap-1 text-xs">
        <span className="truncate text-slate-300" title={fileName}>
          {number}. {fileName} · p{page.index + 1}
        </span>
        <button onClick={onPreview} className="rounded bg-white/10 px-2 py-0.5 hover:bg-white/20">
          View
        </button>
      </div>
      <input
        type="checkbox"
        checked={selected}
        onChange={() => toggle(page.id)}
        aria-label={`Select page ${number}`}
        className="absolute left-3 top-3 h-5 w-5 accent-indigo-500"
      />
    </div>
  );
}
