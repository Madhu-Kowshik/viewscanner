import { useEffect } from 'react';
import { PageCanvas } from './PageCanvas';
import type { PageItem } from '../types';

export function Preview({ page, onClose }: { page: PageItem; onClose: () => void }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);

  const width = Math.min(900, window.innerWidth - 32);
  return (
    <div className="fixed inset-0 z-50 overflow-auto bg-black/80 p-4" onClick={onClose}>
      <div className="mx-auto" style={{ width }} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="mb-2 rounded bg-white/10 px-3 py-1 text-sm hover:bg-white/20">
          Close (Esc)
        </button>
        <PageCanvas sourceId={page.sourceId} index={page.index} rotation={page.rotation} width={width} lazy={false} />
      </div>
    </div>
  );
}
