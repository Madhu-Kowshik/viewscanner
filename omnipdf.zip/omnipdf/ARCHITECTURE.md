# OmniPDF Studio — Architecture (Phase 0)

Tagline: "Everything you need for PDFs."

## Principle
Functionality > number of buttons > visual effects. A feature counts only when the operation runs and the output is verified.

## Stack
- Client: React + TypeScript, Vite, Tailwind, Zustand, dnd-kit, react-dropzone
- PDF: pdf.js (render/text/search), pdf-lib (page ops, annotations, forms, watermark, numbers, crop), JSZip
- OCR: Tesseract.js in a Web Worker
- Server: Node.js + Express/Fastify. Conversion engines: LibreOffice (headless) for Office<->PDF, qpdf (encryption/repair), Ghostscript (compression, PDF/A), MuPDF/pdf-lib for redaction
- Tests: Vitest (unit), Playwright (e2e), fixture PDFs in tests/fixtures

## Core state model (single source of truth, not the DOM)
```
Workspace
  sources: Map<sourceId, { file, bytes(ArrayBuffer), pageCount, name, size }>
  pages: Page[]            // ordered; this array IS the output document
Page { id, sourceId, sourcePageIndex, rotation(0|90|180|270), crop?, selected }
```
- Delete = remove from pages[]; duplicate = new Page id, same source ref; reorder = array move; rotate = rotation delta.
- Export = pdf-lib: for each Page, copyPages from source, apply rotation/crop, add to new doc.
- Source bytes are kept once; thumbnails are lazy canvases rendered at low scale and released when off-screen.

## Where each capability runs
| Class | Features |
|---|---|
| Browser-only | Merge, split, extract, delete, reorder, rotate, duplicate, image->PDF, PDF->image, crop, watermark, page numbers, annotations, visual signature, search, text extraction, compare, form fill, workflow runner |
| Browser + WASM/Worker | OCR (Tesseract.js), raster compression |
| Backend required | Office->PDF, PDF->Office (LibreOffice), true compression (Ghostscript), PDF/A, repair (qpdf/mutool), strong encryption/permissions (qpdf), true redaction (content-stream removal via MuPDF) |
| External service | AI summarize/ask/translate/classify: backend proxy only; key never in client; user told when content leaves the browser |

## Honest limitations
- Editor places overlays; it cannot edit existing PDF text.
- Signature = "Visual PDF signature", not cryptographic.
- pdf-lib has no standard-strength encryption; protect/unlock go through qpdf on the server.
- Redaction must remove underlying text; drawing a box is not redaction. Verified by extracting text afterwards.
- Perspective correction in scanner: not claimed unless implemented.
- PDF->Word/Excel/PPT fidelity from LibreOffice is limited; labeled as such.

## Processing labels in UI
Every tool shows: Local processing | Server processing | External API.

## Security
Validate by magic bytes, not MIME/filename; sanitize filenames; render extracted text as text nodes only; size limits; no secrets in client; temp files on server deleted after response.

## Performance
Lazy thumbnails via IntersectionObserver, render queue with concurrency limit, revoke object URLs, zero out canvases, terminate workers, stop camera tracks.
