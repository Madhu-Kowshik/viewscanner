# OmniPDF Studio
Everything you need for PDFs.

**Status: Phase 1 code written, UNTESTED** (never installed, built or run; the npm registry was unavailable when it was written).

## Run
    cd client
    npm install
    npm run dev      # http://localhost:5173
    npm test         # vitest unit test for the export engine
    npm run build    # type-checks with tsc, then builds

See ARCHITECTURE.md, ROADMAP.md, FEATURE_STATUS.md.
