# FEATURE_STATUS

Statuses: NOT_STARTED, UI_ONLY, PARTIAL, IMPLEMENTED, TESTED

| Feature | UI | Logic | Export | Tested | Status | Notes |
|---|---|---|---|---|---|---|
| Page upload/multi-upload/drag-drop | yes | yes | yes | NO | IMPLEMENTED | UNTESTED (npm registry unavailable; never built or run). Local |
| PDF rendering + thumbnails | yes | yes | yes | NO | IMPLEMENTED | UNTESTED (npm registry unavailable; never built or run). Local |
| Page selection | yes | yes | yes | NO | IMPLEMENTED | UNTESTED (npm registry unavailable; never built or run). Local |
| Delete pages | yes | yes | yes | NO | IMPLEMENTED | UNTESTED (npm registry unavailable; never built or run). Local |
| Rotate pages | yes | yes | yes | NO | IMPLEMENTED | UNTESTED (npm registry unavailable; never built or run). Local |
| Reorder pages | yes | yes | yes | NO | IMPLEMENTED | UNTESTED (npm registry unavailable; never built or run). Local |
| Duplicate pages | yes | yes | yes | NO | IMPLEMENTED | UNTESTED (npm registry unavailable; never built or run). Local |
| Merge | yes | yes | yes | NO | IMPLEMENTED | UNTESTED (npm registry unavailable; never built or run). Local |
| Extract pages | yes | yes | yes | NO | IMPLEMENTED | UNTESTED (npm registry unavailable; never built or run). Local |
| Export PDF | yes | yes | yes | NO | IMPLEMENTED | UNTESTED (npm registry unavailable; never built or run). Local |
| Split (ranges, every page, ZIP) | no | no | no | no | NOT_STARTED | Local |
| Image -> PDF | no | no | no | no | NOT_STARTED | Local |
| PDF -> Image (+ZIP) | no | no | no | no | NOT_STARTED | Local |
| Compression | no | no | no | no | NOT_STARTED | Server (Ghostscript) / Local raster |
| Scanner | no | no | no | no | NOT_STARTED | Local |
| Editor (overlay) | no | no | no | no | NOT_STARTED | Local |
| Annotations | no | no | no | no | NOT_STARTED | Local |
| Visual signature | no | no | no | no | NOT_STARTED | Local |
| Watermark | no | no | no | no | NOT_STARTED | Local |
| Page numbers | no | no | no | no | NOT_STARTED | Local |
| Crop | no | no | no | no | NOT_STARTED | Local |
| OCR | no | no | no | no | NOT_STARTED | Local (Worker) |
| Text extraction | no | no | no | no | NOT_STARTED | Local |
| Search | no | no | no | no | NOT_STARTED | Local |
| Protect/Unlock | no | no | no | no | NOT_STARTED | Server (qpdf) |
| Redaction | no | no | no | no | NOT_STARTED | Server (MuPDF) |
| Forms | no | no | no | no | NOT_STARTED | Local |
| Compare | no | no | no | no | NOT_STARTED | Local |
| Office <-> PDF | no | no | no | no | NOT_STARTED | Server (LibreOffice) |
| PDF/A | no | no | no | no | NOT_STARTED | Server |
| Repair | no | no | no | no | NOT_STARTED | Server |
| AI features | no | no | no | no | NOT_STARTED | External API via backend |
| Workflow automation | no | no | no | no | NOT_STARTED | Local |
| Mobile UX | no | no | no | no | NOT_STARTED | Local |
| Automated tests | no | no | no | no | NOT_STARTED | - |
